package com.example.phamarcy_app;

import android.os.Bundle;
import android.widget.GridView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Home  extends AppCompatActivity {
    GridView coursesGV;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        coursesGV = findViewById(R.id.items);
        ArrayList<com.example.Phamarcy_app.MainMenu> courseModelArrayList = new ArrayList<com.example.Phamarcy_app.MainMenu>();

        courseModelArrayList.add(new com.example.Phamarcy_app.MainMenu("Prescription Management", R.drawable.pill));
        courseModelArrayList.add(new com.example.Phamarcy_app.MainMenu("Search for medication", R.drawable.search));
        courseModelArrayList.add(new com.example.Phamarcy_app.MainMenu("Health profile", R.drawable.profile));
        courseModelArrayList.add(new com.example.Phamarcy_app.MainMenu("Pharmacies near you", R.drawable.location));

        com.example.Phamarcy_app.MainMenuAdapter adapter = new com.example.Phamarcy_app.MainMenuAdapter(this, courseModelArrayList);
        coursesGV.setAdapter(adapter);

    }
}
